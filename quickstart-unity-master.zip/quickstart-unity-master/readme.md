Firebase Unity SDK Samples
==========================

iOS and Android samples for the
[Firebase Unity SDK](https://firebase.google.com/docs/unity/setup).

For more information, see [firebase.google.com](https://firebase.google.com).

## How to make contributions?

Please read and follow the steps in [CONTRIBUTING.md](CONTRIBUTING.md).

## License
See [LICENSE](LICENSE).
